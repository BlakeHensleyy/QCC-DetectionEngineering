from dettectinator import DettectTechniquesAdministration


dettect = DettectTechniquesAdministration(local_stix_path='cti')